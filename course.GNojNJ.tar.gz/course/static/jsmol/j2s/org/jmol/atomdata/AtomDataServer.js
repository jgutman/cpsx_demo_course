Clazz.declarePackage ("org.jmol.atomdata");
Clazz.declareInterface (org.jmol.atomdata, "AtomDataServer");
