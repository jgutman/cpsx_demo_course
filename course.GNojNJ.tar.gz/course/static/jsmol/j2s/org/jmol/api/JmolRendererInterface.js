Clazz.declarePackage ("org.jmol.api");
Clazz.load (["org.jmol.api.JmolGraphicsInterface"], "org.jmol.api.JmolRendererInterface", null, function () {
Clazz.declareInterface (org.jmol.api, "JmolRendererInterface", org.jmol.api.JmolGraphicsInterface);
});
