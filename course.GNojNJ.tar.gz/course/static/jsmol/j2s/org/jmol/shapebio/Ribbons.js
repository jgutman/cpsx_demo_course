Clazz.declarePackage ("org.jmol.shapebio");
Clazz.load (["org.jmol.shapebio.BioShapeCollection"], "org.jmol.shapebio.Ribbons", null, function () {
c$ = Clazz.declareType (org.jmol.shapebio, "Ribbons", org.jmol.shapebio.BioShapeCollection);
});
