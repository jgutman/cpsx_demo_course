Clazz.declarePackage ("org.jmol.shapebio");
Clazz.load (["org.jmol.shapebio.BioShapeCollection"], "org.jmol.shapebio.Strands", null, function () {
c$ = Clazz.decorateAsClass (function () {
this.isMesh = false;
Clazz.instantialize (this, arguments);
}, org.jmol.shapebio, "Strands", org.jmol.shapebio.BioShapeCollection);
});
