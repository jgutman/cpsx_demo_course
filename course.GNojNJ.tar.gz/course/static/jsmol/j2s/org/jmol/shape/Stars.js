Clazz.declarePackage ("org.jmol.shape");
Clazz.load (["org.jmol.shape.AtomShape"], "org.jmol.shape.Stars", null, function () {
c$ = Clazz.declareType (org.jmol.shape, "Stars", org.jmol.shape.AtomShape);
});
