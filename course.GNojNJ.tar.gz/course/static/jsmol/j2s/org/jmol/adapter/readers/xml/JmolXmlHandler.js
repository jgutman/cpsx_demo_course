Clazz.declarePackage ("org.jmol.adapter.readers.xml");
Clazz.declareInterface (org.jmol.adapter.readers.xml, "JmolXmlHandler");
