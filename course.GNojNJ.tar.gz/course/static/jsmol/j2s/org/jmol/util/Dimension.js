Clazz.declarePackage ("org.jmol.util");
c$ = Clazz.decorateAsClass (function () {
this.height = 0;
this.width = 0;
Clazz.instantialize (this, arguments);
}, org.jmol.util, "Dimension");
