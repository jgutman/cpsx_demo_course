Clazz.declarePackage ("org.jmol.util");
Clazz.declareInterface (org.jmol.util, "LoggerInterface");
