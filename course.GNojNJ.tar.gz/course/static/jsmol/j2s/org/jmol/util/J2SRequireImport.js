Clazz.declarePackage ("org.jmol.util");
