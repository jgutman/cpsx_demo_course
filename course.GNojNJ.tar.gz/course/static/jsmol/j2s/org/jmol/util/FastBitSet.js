Clazz.declarePackage ("org.jmol.util");
c$ = Clazz.declareType (org.jmol.util, "FastBitSet", null, Cloneable);
